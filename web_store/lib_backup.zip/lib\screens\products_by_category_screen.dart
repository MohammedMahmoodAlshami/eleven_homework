import 'package:flutter/material.dart';
import '../models/category.dart';
import '../data/dummy_data.dart';
import '../widgets/product_card.dart';
import '../widgets/custom_app_bar.dart';

class ProductsByCategoryScreen extends StatelessWidget {
  final Category category;

const ProductsByCategoryScreen({
  super.key,
  required this.category,
});


  @override
  Widget build(BuildContext context) {
    final categoryProducts = products
        .where((product) => product.categoryId == category.id)
        .toList();

    return Scaffold(
      appBar: CustomAppBar(title: category.name, showBackButton: true),
      body: categoryProducts.isEmpty
          ? Center(
              child: Text(
                'لا توجد منتجات في هذا القسم',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800),
              ),
            )

          : Directionality(
              textDirection: TextDirection.rtl,
              child: GridView.builder(
                  padding: EdgeInsets.all(12),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                     crossAxisCount: 2,
                     //determine the height
                     childAspectRatio: 0.7,
                     crossAxisSpacing: 10,
                     mainAxisSpacing: 10,
                  ),
                  itemCount: categoryProducts.length,
                  itemBuilder: (context, i) => ProductCard(product: categoryProducts[i]),
                ),
            ),
         
    );
  }
}
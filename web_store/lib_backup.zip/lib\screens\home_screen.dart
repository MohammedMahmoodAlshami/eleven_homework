import 'package:flutter/material.dart';
import '../data/dummy_data.dart';
import '../widgets/product_card.dart';
import '../widgets/category_card.dart';
import 'favorites_screen.dart';
import 'Cart_Screen.dart';


class HomeScreen extends StatelessWidget {
  const HomeScreen ({super.key});
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final textTheme = theme.textTheme;
    final popularProducts = products.where((p) => p.isPopular).toList();

   
    return Scaffold(
appBar: AppBar(
  automaticallyImplyLeading: false,
  // اجعل المسافة بين بداية AppBar والعنوان = 12 بكسل
  titleSpacing: 12,
    elevation: 0,
  backgroundColor: Colors.white,

   title: Row(
    mainAxisAlignment: MainAxisAlignment.spaceBetween,

    children: [

      InkWell(
        borderRadius: BorderRadius.circular(15),

        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => FavoritesScreen(),
            ),
          );
        },

        child:  Container(
          padding: const EdgeInsets.symmetric( horizontal: 14,  vertical: 10,  ),

          decoration: BoxDecoration(
            color: Colors.red.shade50,
            borderRadius: BorderRadius.circular(15),
          ),

          child: Row(
            children: const [

              Icon(
                Icons.favorite,
                color: Colors.red,
                size: 22,
              ),

              SizedBox(width: 6),

              Text(
                'المفضلة',
                style: TextStyle(
                  color: Colors.red,
                  fontWeight: FontWeight.bold,
                  fontSize: 15,
                ),
              ),
            ],
          ),
        ),
      ),


      Row(
        children:  [

         const Text(
            'متجر الموشكي',
            style: TextStyle(
              color: Colors.black,
              fontWeight: FontWeight.bold,
              fontSize: 17,
            ),
          ),

          SizedBox(width: 10),

    InkWell(

     onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => CartScreen(),
            ),
          );
        },
        child:  Icon(
            Icons.shopping_cart_outlined,
            color: Colors.black,
            size: 25,
          ), 
          )
        ],
      ),

      
    ],
  ),
),





     
     
     
     
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            // Banner ترحيبي
            Container(
              margin: EdgeInsets.all(16),
              padding: EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    colorScheme.primary,
                    colorScheme.tertiary,
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(25),
              ),
              child: Row(
                textDirection: TextDirection.rtl,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        'مرحباً بك ',
                        style: textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.w900,
                          color: colorScheme.onPrimary,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        'اكتشف أفضل العروض',
                        style: textTheme.bodyMedium?.copyWith(
                          color: colorScheme.onPrimary.withValues(alpha: 0.85),
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                  Spacer(),
                  Icon(Icons.storefront, size: 50, color: colorScheme.onPrimary),
                ],
              ),
            ),


           
            // الأقسام
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                // crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                 
                  TextButton(
                    onPressed: () {
                      Navigator.pushNamed(context, '/categories');
                    },
                    
                    child: Text(
                      'عرض الكل',
                      style: textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w900,fontSize: 18

                      ),
                    ),
                  ), Text(
                    'الأقسام',
                    style: textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                'اختر القسم المناسب لك بسرعة',
                style: textTheme.bodyMedium?.copyWith(
                  color: colorScheme.onSurfaceVariant,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            SizedBox(height: 10),
            SizedBox(
              height: 160,
              child: ListView.builder(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.symmetric(horizontal: 6),
                scrollDirection: Axis.horizontal,
                itemCount: categories.length,
                itemBuilder: (ctx, i) => CategoryCard(category: categories[i]),
              ),
            ),
            
            // المنتجات الشائعة
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 16),
              child: Text(
                'المنتجات الشائعة ',
                style: textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
            Directionality(
              textDirection: TextDirection.rtl,
              child: GridView.builder(
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                padding: EdgeInsets.symmetric(horizontal: 8),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  childAspectRatio: 0.7,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                ),
                itemCount: popularProducts.length,
                itemBuilder: (ctx, i) {
                  return ProductCard(product: popularProducts[i]);
                },
              ),
            ),
            
            SizedBox(height: 80), // مساحة للسفل
          ],
        ),
      ),
    );
  }
}